import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Home, Search, User, Play, Lock, Clock3, Eye, Film, Settings,
  Shield, Plus, Pencil, Trash2, LogOut, BarChart3, Megaphone,
  Tags, Users, Wrench, ChevronLeft, X
} from "lucide-react";
import { signInWithCustomToken } from "firebase/auth";
import {
  collection, query, where, orderBy, limit, getDocs, doc, getDoc,
  addDoc, setDoc, updateDoc, deleteDoc, serverTimestamp
} from "firebase/firestore";
import { auth, db } from "./firebase";
import { initTelegram, telegramInitData, telegramUser } from "./telegram";
import { telegramAuth, claimReward, incrementView, adminAction } from "./api";
import { showRewardAd } from "./adsgram";
import "./styles.css";

const DEFAULT_SETTINGS = {
  appName: "RK Video",
  logoUrl: "",
  description: "Watch videos by completing rewarded ads.",
  adsgramBlockId: import.meta.env.VITE_ADSGRAM_BLOCK_ID || "",
  defaultAds: 1,
  unlockDurationMinutes: 1440,
  adsEnabled: true,
  maintenance: false,
  supportUsername: "",
  channelUrl: ""
};

function fmtDate(ts) {
  if (!ts) return "";
  const d = ts?.toDate ? ts.toDate() : new Date(ts);
  return d.toLocaleString("en-GB");
}

function App() {
  const [route, setRoute] = useState(location.pathname);
  const [user, setUser] = useState(telegramUser());
  const [profile, setProfile] = useState(null);
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [videos, setVideos] = useState([]);
  const [categories, setCategories] = useState([]);
  const [unlocks, setUnlocks] = useState({});
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState("home");
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState("");

  const adminMode = route === "/adminriad";

  useEffect(() => {
    initTelegram();
    bootstrap();
  }, []);

  async function bootstrap() {
    try {
      const initData = telegramInitData();
      if (initData) {
        const result = await telegramAuth({ initData });
        await signInWithCustomToken(auth, result.data.token);
        setUser(result.data.user);
        setProfile(result.data.profile);
      } else if (import.meta.env.VITE_DEV_MODE === "true") {
        setUser({ id: "dev-user", first_name: "Developer", username: "dev" });
      }
      await loadSettings();
      await loadVideos();
      await loadCategories();
      setLoading(false);
    } catch (e) {
      console.error(e);
      setNotice("Telegram/Firebase setup is not complete yet.");
      setLoading(false);
    }
  }

  async function loadSettings() {
    const s = await getDoc(doc(db, "settings", "app"));
    if (s.exists()) setSettings({ ...DEFAULT_SETTINGS, ...s.data() });
  }

  async function loadVideos() {
    const q = query(
      collection(db, "videos"),
      where("status", "==", "active"),
      orderBy("createdAt", "desc"),
      limit(100)
    );
    const snap = await getDocs(q);
    setVideos(snap.docs.map(d => ({ id: d.id, ...d.data() })));
  }

  async function loadCategories() {
    const q = query(collection(db, "categories"), where("status", "==", "active"), limit(50));
    const snap = await getDocs(q);
    setCategories(snap.docs.map(d => ({ id: d.id, ...d.data() })));
  }

  function isUnlocked(videoId) {
    const u = unlocks[videoId];
    return u && (!u.expiresAt || new Date(u.expiresAt).getTime() > Date.now());
  }

  async function openVideo(video) {
    setSelected(video);
    try { await incrementView({ videoId: video.id }); } catch {}
  }

  if (adminMode) {
    return <AdminPanel settings={settings} setSettings={setSettings} videos={videos} reload={async()=>{await loadVideos();await loadCategories();}} />;
  }

  if (loading) return <div className="center"><div className="spinner"/><p>লোড হচ্ছে...</p></div>;

  if (settings.maintenance) {
    return <div className="center"><Wrench size={42}/><h2>Maintenance</h2><p>অ্যাপটি সাময়িকভাবে বন্ধ আছে। পরে আবার চেষ্টা করুন।</p></div>;
  }

  const filtered = videos.filter(v =>
    !search ||
    (v.title || "").toLowerCase().includes(search.toLowerCase()) ||
    (v.description || "").toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          {settings.logoUrl ? <img src={settings.logoUrl} alt="" /> : <div className="logo">RK</div>}
          <div><b>{settings.appName}</b><small>Video Sharing</small></div>
        </div>
        <button className="icon-btn" onClick={()=>setTab("profile")}><User size={20}/></button>
      </header>

      {notice && <div className="notice"><span>{notice}</span><button onClick={()=>setNotice("")}><X size={16}/></button></div>}

      {tab === "home" && (
        <>
          <section className="hero">
            <div>
              <span className="eyebrow">WELCOME</span>
              <h1>Hi, {user?.first_name || "there"} 👋</h1>
              <p>{settings.description}</p>
            </div>
            <Film size={52} strokeWidth={1.5}/>
          </section>
          <SearchBox value={search} setValue={setSearch}/>
          <SectionTitle title="Latest Videos"/>
          <VideoGrid videos={filtered.slice(0, 12)} onOpen={openVideo} unlocked={isUnlocked}/>
          <SectionTitle title="Categories"/>
          <div className="chips">
            {categories.map(c => <button key={c.id} onClick={()=>{setSearch(c.name);setTab("videos")}}>{c.icon || "🎬"} {c.name}</button>)}
          </div>
        </>
      )}

      {tab === "videos" && (
        <>
          <SearchBox value={search} setValue={setSearch}/>
          <SectionTitle title="All Videos"/>
          <VideoGrid videos={filtered} onOpen={openVideo} unlocked={isUnlocked}/>
        </>
      )}

      {tab === "profile" && (
        <Profile user={user} profile={profile} videos={videos} />
      )}

      {selected && (
        <VideoModal
          video={selected}
          settings={settings}
          unlocked={isUnlocked(selected.id)}
          onClose={()=>setSelected(null)}
          onUnlocked={u=>setUnlocks(x=>({...x,[selected.id]:u}))}
          setNotice={setNotice}
        />
      )}

      <nav className="bottom-nav">
        <button className={tab==="home"?"active":""} onClick={()=>{setTab("home");setSearch("")}}><Home/><span>Home</span></button>
        <button className={tab==="videos"?"active":""} onClick={()=>setTab("videos")}><Film/><span>Videos</span></button>
        <button className={tab==="profile"?"active":""} onClick={()=>setTab("profile")}><User/><span>Profile</span></button>
      </nav>
    </div>
  );
}

function SearchBox({value,setValue}) {
  return <div className="searchbox"><Search size={19}/><input value={value} onChange={e=>setValue(e.target.value)} placeholder="ভিডিও খুঁজুন..."/>{value && <button onClick={()=>setValue("")}><X size={17}/></button>}</div>;
}

function SectionTitle({title}) { return <div className="section-title"><h2>{title}</h2></div>; }

function VideoGrid({videos,onOpen,unlocked}) {
  if (!videos.length) return <div className="empty"><Film size={34}/><p>কোনো ভিডিও পাওয়া যায়নি</p></div>;
  return <div className="video-grid">{videos.map(v=><article className="video-card" key={v.id} onClick={()=>onOpen(v)}>
    <div className="thumb">
      {v.thumbnailUrl ? <img src={v.thumbnailUrl} alt={v.title}/> : <div className="thumb-fallback"><Film/></div>}
      <span className="duration">{v.duration || "HD"}</span>
      {!unlocked(v.id) && <span className="lock"><Lock size={15}/></span>}
    </div>
    <div className="video-meta"><h3>{v.title}</h3><div><span><Eye size={13}/> {v.views || 0}</span><span>{v.categoryName || "Video"}</span></div></div>
  </article>)}</div>;
}

function Profile({user,profile,videos}) {
  return <section className="profile-page">
    <div className="profile-card">
      <div className="avatar">{(user?.first_name || "U").slice(0,1).toUpperCase()}</div>
      <h2>{user?.first_name || "Telegram User"}</h2>
      <p>@{user?.username || "unknown"}</p>
    </div>
    <div className="stats">
      <div><b>{profile?.totalVideosWatched || 0}</b><span>Videos</span></div>
      <div><b>{profile?.totalAdsWatched || 0}</b><span>Ads</span></div>
      <div><b>{profile?.totalUnlocks || 0}</b><span>Unlocks</span></div>
    </div>
    <div className="settings-list">
      <div><Settings/><span>App Version</span><b>1.0.0</b></div>
      {profile?.isAdmin && <a href="/adminriad"><Shield/><span>Admin Panel</span></a>}
    </div>
  </section>;
}

function VideoModal({video,settings,unlocked,onClose,onUnlocked,setNotice}) {
  const [busy,setBusy] = useState(false);
  const [progress,setProgress] = useState(0);
  const required = Math.max(1, Number(video.requiredAds ?? settings.defaultAds ?? 1));

  async function watchAd() {
    if (busy) return;
    if (!settings.adsEnabled) { setNotice("Ads বর্তমানে বন্ধ আছে।"); return; }
    setBusy(true);
    try {
      await showRewardAd(settings.adsgramBlockId);
      const result = await claimReward({ videoId: video.id });
      setProgress(result.data.adsCompleted || required);
      if (result.data.unlocked) {
        onUnlocked({ expiresAt: result.data.expiresAt || null });
        setNotice("✅ ভিডিও আনলক হয়েছে!");
      } else {
        setNotice(`Ad complete! আরও ${result.data.remaining} টি ad লাগবে।`);
      }
    } catch (e) {
      console.error(e);
      setNotice(e?.message || "Ad complete হয়নি।");
    } finally { setBusy(false); }
  }

  return <div className="modal-backdrop" onClick={onClose}>
    <div className="modal" onClick={e=>e.stopPropagation()}>
      <button className="close" onClick={onClose}><X/></button>
      <div className="player">
        {unlocked ? (
          <video controls playsInline poster={video.thumbnailUrl} src={video.videoUrl || ""}/>
        ) : video.thumbnailUrl ? <img src={video.thumbnailUrl} alt={video.title}/> : <Film size={55}/>}
      </div>
      <div className="modal-body">
        <span className="eyebrow">{video.categoryName || "VIDEO"}</span>
        <h2>{video.title}</h2>
        <p>{video.description || "No description."}</p>
        {!unlocked ? <div className="unlock-box">
          <div className="unlock-icon"><Lock/></div>
          <h3>Video Locked</h3>
          <p>ভিডিও দেখতে rewarded ad সম্পূর্ণ করুন।</p>
          <div className="progress-label"><span>Progress</span><b>{progress}/{required}</b></div>
          <div className="progress"><i style={{width:`${Math.min(100,(progress/required)*100)}%`}}/></div>
          <button className="primary" disabled={busy} onClick={watchAd}>
            {busy ? "Ad loading..." : "🎬 Watch Ad"}
          </button>
        </div> : <div className="unlocked"><Play fill="currentColor"/><span>Video unlocked — এখন Play করুন</span></div>}
      </div>
    </div>
  </div>;
}

function AdminPanel({settings,setSettings,videos,reload}) {
  const [authed,setAuthed]=useState(false);
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [section,setSection]=useState("dashboard");
  const [saving,setSaving]=useState(false);
  const [msg,setMsg]=useState("");

  useEffect(()=>{ checkAdmin(); },[]);
  async function checkAdmin() {
    try {
      const r = await adminAction({action:"check"});
      setAuthed(!!r.data?.isAdmin);
    } catch {}
  }
  async function login(e) {
    e.preventDefault();
    try {
      const { signInWithEmailAndPassword } = await import("firebase/auth");
      await signInWithEmailAndPassword(auth,email,password);
      const r = await adminAction({action:"check"});
      if (!r.data?.isAdmin) throw new Error("Access denied");
      setAuthed(true);
    } catch(e) { setMsg(e.message || "Login failed"); }
  }
  async function saveSettings(e) {
    e.preventDefault(); setSaving(true);
    try {
      await adminAction({action:"saveSettings", data:settings});
      setMsg("Settings saved");
    } catch(e) { setMsg(e.message || "Save failed"); }
    finally { setSaving(false); }
  }

  if (!authed) return <div className="admin-login">
    <div className="admin-login-card"><div className="logo big">RK</div><h1>Admin Panel</h1><p>Secure administrator login</p>
      <form onSubmit={login}><input type="email" placeholder="Admin email" value={email} onChange={e=>setEmail(e.target.value)} required/><input type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} required/><button className="primary">Login</button></form>
      {msg && <div className="error">{msg}</div>}
    </div>
  </div>;

  return <div className="admin-shell">
    <aside className="admin-side">
      <div className="admin-brand"><div className="logo">RK</div><b>Admin</b></div>
      {[
        ["dashboard","Dashboard",BarChart3],["videos","Videos",Film],["users","Users",Users],
        ["ads","Ads & Unlocks",Megaphone],["categories","Categories",Tags],["broadcast","Broadcast",Megaphone],
        ["settings","Settings",Settings]
      ].map(([id,label,Icon])=><button key={id} className={section===id?"active":""} onClick={()=>setSection(id)}><Icon/><span>{label}</span></button>)}
      <a href="/"><ChevronLeft/> Back to App</a>
    </aside>
    <main className="admin-main">
      <div className="admin-top"><h1>{section}</h1><span>{msg}</span></div>
      {section==="dashboard" && <AdminDashboard videos={videos}/>}
      {section==="videos" && <AdminVideos videos={videos} reload={reload}/>}
      {section==="settings" && <form className="settings-form" onSubmit={saveSettings}>
        <h2>App Settings</h2>
        {Object.entries(settings).map(([k,v])=>{
          if (typeof v === "boolean") return <label className="check" key={k}><input type="checkbox" checked={v} onChange={e=>setSettings({...settings,[k]:e.target.checked})}/>{k}</label>;
          return <label key={k}>{k}<input value={v ?? ""} onChange={e=>setSettings({...settings,[k]:e.target.value})}/></label>
        })}
        <button className="primary" disabled={saving}>{saving?"Saving...":"Save Settings"}</button>
      </form>}
      {section!=="dashboard" && section!=="videos" && section!=="settings" && <div className="coming">Admin module <b>{section}</b> is connected to the backend and can be extended from the same panel.</div>}
    </main>
  </div>;
}

function AdminDashboard({videos}) {
  return <div className="dashboard">
    <div className="metric"><Film/><b>{videos.length}</b><span>Active Videos</span></div>
    <div className="metric"><Users/><b>—</b><span>Total Users</span></div>
    <div className="metric"><Megaphone/><b>—</b><span>Ad Views</span></div>
    <div className="metric"><BarChart3/><b>—</b><span>Unlocks</span></div>
    <div className="admin-card"><h2>System</h2><p>Use the Videos and Settings sections to configure the app.</p></div>
  </div>;
}

function AdminVideos({videos,reload}) {
  const empty={title:"",description:"",thumbnailUrl:"",videoUrl:"",categoryName:"",duration:"",requiredAds:1,unlockType:"timed",unlockDurationMinutes:1440,status:"active"};
  const [form,setForm]=useState(empty);
  const [editing,setEditing]=useState(null);
  const [saving,setSaving]=useState(false);
  async function save(e) {
    e.preventDefault(); setSaving(true);
    try {
      if (editing) await adminAction({action:"updateVideo",id:editing,data:form});
      else await adminAction({action:"createVideo",data:form});
      setForm(empty); setEditing(null); await reload();
    } catch(e) { alert(e.message || "Save failed"); }
    finally { setSaving(false); }
  }
  async function remove(id) {
    if (!confirm("Delete this video?")) return;
    await adminAction({action:"deleteVideo",id}); await reload();
  }
  return <div className="admin-grid">
    <form className="admin-card" onSubmit={save}>
      <h2>{editing?"Edit Video":"Add Video"}</h2>
      {Object.entries(form).map(([k,v])=><label key={k}>{k}<input type={k==="requiredAds"||k==="unlockDurationMinutes"?"number":"text"} value={v ?? ""} onChange={e=>setForm({...form,[k]:(k==="requiredAds"||k==="unlockDurationMinutes")?Number(e.target.value):e.target.value})}/></label>)}
      <div className="row"><button className="primary" disabled={saving}>{saving?"Saving...":"Save Video"}</button>{editing&&<button type="button" onClick={()=>{setEditing(null);setForm(empty)}}>Cancel</button>}</div>
    </form>
    <div className="admin-card table-card"><h2>Videos</h2>{videos.map(v=><div className="table-row" key={v.id}><div><b>{v.title}</b><small>{v.requiredAds || 1} ads • {v.unlockDurationMinutes || 1440} min</small></div><div className="row"><button onClick={()=>{setEditing(v.id);setForm({...empty,...v})}}><Pencil size={16}/></button><button onClick={()=>remove(v.id)}><Trash2 size={16}/></button></div></div>)}</div>
  </div>;
}

createRoot(document.getElementById("root")).render(<App />);
