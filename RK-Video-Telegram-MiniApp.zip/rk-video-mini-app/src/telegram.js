export const tg = window.Telegram?.WebApp || null;

export function initTelegram() {
  if (!tg) return null;
  tg.ready();
  tg.expand();
  try { tg.enableClosingConfirmation(); } catch {}
  return tg;
}

export function telegramUser() {
  return tg?.initDataUnsafe?.user || null;
}

export function telegramInitData() {
  return tg?.initData || "";
}
