import { httpsCallable } from "firebase/functions";
import { functions } from "./firebase";

export const telegramAuth = httpsCallable(functions, "telegramAuth");
export const claimReward = httpsCallable(functions, "claimReward");
export const getMyUnlocks = httpsCallable(functions, "getMyUnlocks");
export const incrementView = httpsCallable(functions, "incrementView");
export const adminAction = httpsCallable(functions, "adminAction");
