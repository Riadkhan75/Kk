let controller = null;

export function initAdsgram(blockId) {
  if (!blockId || blockId === "YOUR_ADSGRAM_BLOCK_ID") return null;
  if (!window.Adsgram) throw new Error("Adsgram SDK not loaded");
  controller = window.Adsgram.init({ blockId });
  return controller;
}

export async function showRewardAd(blockId) {
  const ad = controller || initAdsgram(blockId);
  if (!ad) throw new Error("Adsgram Block ID is not configured.");
  const result = await ad.show();
  if (!result?.done) throw new Error("Ad was not completed.");
  return result;
}
