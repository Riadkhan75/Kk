const crypto = require("crypto");
const { onCall, onRequest, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore, FieldValue, Timestamp } = require("firebase-admin/firestore");
const logger = require("firebase-functions/logger");

initializeApp();
const db = getFirestore();

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "";
const WEBAPP_MAX_AGE = 86400;

function validateTelegramInitData(initData) {
  if (!BOT_TOKEN || !initData) throw new Error("Telegram backend is not configured.");
  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  const authDate = Number(params.get("auth_date") || 0);
  if (!hash || !authDate) throw new Error("Invalid Telegram initData.");
  if (Math.floor(Date.now()/1000) - authDate > WEBAPP_MAX_AGE) throw new Error("Telegram session expired.");

  const dataCheckString = [...params.entries()]
    .filter(([k]) => k !== "hash")
    .sort(([a],[b]) => a.localeCompare(b))
    .map(([k,v]) => `${k}=${v}`)
    .join("\n");

  const secretKey = crypto.createHmac("sha256", "WebAppData").update(BOT_TOKEN).digest();
  const calculated = crypto.createHmac("sha256", secretKey).update(dataCheckString).digest("hex");

  if (!crypto.timingSafeEqual(Buffer.from(calculated), Buffer.from(hash))) {
    throw new Error("Telegram signature validation failed.");
  }

  const user = JSON.parse(params.get("user") || "{}");
  if (!user.id) throw new Error("Telegram user missing.");
  return user;
}

async function settings() {
  const snap = await db.doc("settings/app").get();
  return snap.exists ? snap.data() : {
    defaultAds: 1,
    unlockDurationMinutes: 1440,
    adsEnabled: true
  };
}

async function isAdmin(uid) {
  return (await db.doc(`admins/${uid}`).get()).exists;
}

exports.telegramAuth = onCall(async (request) => {
  const initData = request.data?.initData;
  try {
    const user = validateTelegramInitData(initData);
    const uid = `tg_${user.id}`;
    const ref = db.doc(`users/${uid}`);
    const snap = await ref.get();
    const base = {
      telegramId: String(user.id),
      firstName: user.first_name || "",
      lastName: user.last_name || "",
      username: user.username || "",
      photoUrl: user.photo_url || "",
      lastActive: FieldValue.serverTimestamp(),
      status: "active"
    };
    if (!snap.exists) {
      await ref.set({...base, joinDate: FieldValue.serverTimestamp(), totalAdsWatched:0, totalVideosWatched:0, totalUnlocks:0});
    } else {
      await ref.set(base, {merge:true});
    }
    const token = await getAuth().createCustomToken(uid, {
      telegramId: String(user.id),
      isAdmin: await isAdmin(uid)
    });
    return {token, user, profile: {...base, isAdmin: await isAdmin(uid)}};
  } catch (e) {
    logger.error(e);
    throw new HttpsError("unauthenticated", e.message);
  }
});

exports.claimReward = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Login required.");
  const uid = request.auth.uid;
  const videoId = String(request.data?.videoId || "");
  if (!videoId) throw new HttpsError("invalid-argument", "videoId required.");

  const videoRef = db.doc(`videos/${videoId}`);
  const userRef = db.doc(`users/${uid}`);
  const unlockRef = db.doc(`unlocks/${uid}_${videoId}`);
  const snap = await videoRef.get();
  if (!snap.exists || snap.data().status !== "active") throw new HttpsError("not-found", "Video unavailable.");

  const video = snap.data();
  const s = await settings();
  const required = Math.max(1, Number(video.requiredAds ?? s.defaultAds ?? 1));

  return db.runTransaction(async tx => {
    const [uSnap, unlockSnap] = await Promise.all([tx.get(userRef), tx.get(unlockRef)]);
    const old = unlockSnap.exists ? unlockSnap.data() : {};
    const now = Date.now();
    if (old.expiresAt && old.expiresAt.toMillis && old.expiresAt.toMillis() > now && old.status === "unlocked") {
      return {unlocked:true, adsCompleted:required, remaining:0, expiresAt:old.expiresAt.toDate().toISOString()};
    }

    const completed = Math.min(required, Number(old.adsCompleted || 0) + 1);
    const unlocked = completed >= required;
    let expiresAt = null;
    if (unlocked && (video.unlockType || "timed") === "timed") {
      const mins = Math.max(1, Number(video.unlockDurationMinutes ?? s.unlockDurationMinutes ?? 1440));
      expiresAt = Timestamp.fromMillis(now + mins * 60000);
    }

    const data = {
      userId: uid, videoId, adsRequired: required, adsCompleted: completed,
      status: unlocked ? "unlocked" : "progress",
      updatedAt: FieldValue.serverTimestamp()
    };
    if (unlocked) data.expiresAt = expiresAt;

    tx.set(unlockRef, data, {merge:true});
    tx.set(userRef, {
      totalAdsWatched: Number(uSnap.data()?.totalAdsWatched || 0) + 1,
      ...(unlocked ? {totalUnlocks: Number(uSnap.data()?.totalUnlocks || 0) + 1} : {})
    }, {merge:true});

    return {
      unlocked, adsCompleted:completed, remaining:Math.max(0, required-completed),
      expiresAt: expiresAt ? expiresAt.toDate().toISOString() : null
    };
  });
});

exports.incrementView = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Login required.");
  const id = String(request.data?.videoId || "");
  if (!id) throw new HttpsError("invalid-argument", "videoId required.");
  await db.doc(`videos/${id}`).set({views:FieldValue.increment(1)}, {merge:true});
  await db.collection("watchHistory").add({
    userId:request.auth.uid, videoId:id, watchedAt:FieldValue.serverTimestamp()
  });
  await db.doc(`users/${request.auth.uid}`).set({
    totalVideosWatched:FieldValue.increment(1), lastActive:FieldValue.serverTimestamp()
  }, {merge:true});
  return {ok:true};
});

exports.adminAction = onCall(async (request) => {
  if (!request.auth || !(await isAdmin(request.auth.uid))) {
    throw new HttpsError("permission-denied", "Admin access denied.");
  }
  const action = request.data?.action;
  if (action === "check") return {isAdmin:true};

  if (action === "saveSettings") {
    await db.doc("settings/app").set(request.data.data || {}, {merge:true});
    return {ok:true};
  }

  if (action === "createVideo") {
    const data = {...request.data.data, createdAt:FieldValue.serverTimestamp(), updatedAt:FieldValue.serverTimestamp(), views:0};
    const ref = await db.collection("videos").add(data);
    return {id:ref.id};
  }

  if (action === "updateVideo") {
    await db.doc(`videos/${request.data.id}`).set({...request.data.data, updatedAt:FieldValue.serverTimestamp()}, {merge:true});
    return {ok:true};
  }

  if (action === "deleteVideo") {
    await db.doc(`videos/${request.data.id}`).delete();
    return {ok:true};
  }

  throw new HttpsError("invalid-argument", "Unknown admin action.");
});

/*
  Optional AdsGram server-side reward endpoint.

  Configure AdsGram Reward URL as:
  https://<REGION>-<PROJECT_ID>.cloudfunctions.net/adsgramReward?userid=[userId]

  AdsGram documents that the Reward URL can receive the Telegram ID after
  a real rewarded ad; this endpoint converts that verified credit into a
  server-side balance. The Mini App can consume that balance in a stricter
  production reward flow.
*/
exports.adsgramReward = onRequest(async (req, res) => {
  try {
    const userId = String(req.query.userid || "");
    if (!userId) return res.status(400).send("missing userid");
    const uid = `tg_${userId}`;
    await db.doc(`users/${uid}`).set({
      verifiedAdCredits: FieldValue.increment(1),
      lastVerifiedAd: FieldValue.serverTimestamp()
    }, {merge:true});
    return res.status(200).send("OK");
  } catch (e) {
    logger.error(e);
    return res.status(500).send("ERROR");
  }
});
