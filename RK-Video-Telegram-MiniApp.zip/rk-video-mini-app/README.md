# RK Video — Telegram Mini App + AdsGram + Firebase

This starter is already wired for:
- Telegram Mini App authentication
- Firebase Auth custom tokens
- Firestore
- AdsGram rewarded ads
- Per-video ad requirement
- Timed unlocks
- `/adminriad` admin route
- Firebase callable backend
- Optional AdsGram Reward URL endpoint

## 1. Install

```bash
npm install
cd functions
npm install
cd ..
```

## 2. Firebase

Create a Firebase project and enable:
- Authentication > Email/Password
- Firestore

Copy the web app config into `.env`.

Then initialize/deploy:

```bash
firebase login
firebase use YOUR_PROJECT_ID
firebase deploy --only firestore:rules,firestore:indexes,functions,hosting
```

If you are only using Vercel for the frontend, deploy the functions separately with Firebase CLI and deploy `dist` to Vercel.

## 3. Telegram Bot Token

Never put the bot token in VITE_* variables.

For Firebase Functions environment/secrets, set:

```bash
firebase functions:secrets:set TELEGRAM_BOT_TOKEN
```

Then update the function to read the secret according to your Firebase Functions version, or use the Firebase Functions environment configuration supported by your project.

The code currently reads `process.env.TELEGRAM_BOT_TOKEN`.

## 4. AdsGram

AdsGram's current rewarded integration uses:

```html
<script src="https://sad.adsgram.ai/js/sad.min.js"></script>
```

and:

```js
const AdController = window.Adsgram.init({ blockId: "YOUR_BLOCK_ID" });
await AdController.show();
```

Put your Block ID in:

`.env`

```text
VITE_ADSGRAM_BLOCK_ID=YOUR_BLOCK_ID
```

For a stronger server-side reward setup, configure the optional AdsGram Reward URL to:

```text
https://us-central1-YOUR_PROJECT_ID.cloudfunctions.net/adsgramReward?userid=[userId]
```

Then use the verified credit flow in your production reward logic.

## 5. Create first admin

Create an Email/Password user in Firebase Authentication.

Copy the user's Firebase UID.

In Firestore create:

Collection: `admins`

Document ID: that UID

Example:

```json
{
  "role": "admin",
  "active": true
}
```

Then open:

`/adminriad`

The frontend checks admin status through the callable backend.

## 6. Telegram Mini App

Use BotFather to create/configure the Mini App and set its URL to your deployed frontend URL.

The Mini App sends `Telegram.WebApp.initData` to the backend. The backend validates the Telegram signature before creating a Firebase custom token.

Do not trust `initDataUnsafe` for authentication.

## 7. Video setup

From `/adminriad`:
- Videos
- Add Video
- Add title
- Thumbnail URL
- Direct video URL
- Required Ads
- Unlock duration
- Save

Example:
Required Ads = 2
Unlock Duration = 1440

The user must complete two rewarded ads and then gets 24-hour access.

## 8. Important production note

AdsGram's client callback confirms the rewarded ad flow to the browser. For high-value production systems, configure the AdsGram Reward URL and build the final reward consumption around the server-side verified credit.

Never trust a client-supplied `adsCompleted` value.

## 9. Vercel frontend

```bash
npm run build
```

Set the VITE_* variables in Vercel Environment Variables.

Build command:
`npm run build`

Output directory:
`dist`

## 10. Do not commit

Never upload:
- bot token
- Firebase Admin private key
- service account JSON
- real `.env`

Commit only `.env.example`.

## 11. Current UI

User:
- Home
- Search
- Videos
- Categories
- Profile
- Video modal
- Rewarded unlock

Admin:
- Dashboard
- Videos
- Settings
- Users/Ads/Broadcast/Categories sections ready for backend expansion
